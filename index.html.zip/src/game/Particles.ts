import * as THREE from 'three';

interface Particle {
  mesh: THREE.Mesh;
  velocity: THREE.Vector3;
  life: number;
  maxLife: number;
}

export class ParticleSystem {
  private particles: Particle[] = [];
  private scene: THREE.Scene;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
  }

  spawnExplosion(x: number, y: number, color: number = 0xffd700, count: number = 18) {
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2 + Math.random() * 0.3;
      const speed = 2 + Math.random() * 4;
      const size = 0.06 + Math.random() * 0.18;

      const geo = new THREE.SphereGeometry(size, 5, 5);
      const mat = new THREE.MeshBasicMaterial({ color });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(x + (Math.random() - 0.5) * 0.3, y + (Math.random() - 0.5) * 0.3, (Math.random() - 0.5) * 0.5);
      this.scene.add(mesh);

      this.particles.push({
        mesh,
        velocity: new THREE.Vector3(
          Math.cos(angle) * speed,
          Math.sin(angle) * speed,
          (Math.random() - 0.5) * 2
        ),
        life: 0,
        maxLife: 0.5 + Math.random() * 0.5,
      });
    }
  }

  spawnFeathers(x: number, y: number) {
    const colors = [0xffd700, 0xff8c00, 0xffe066];
    for (let i = 0; i < 10; i++) {
      const color = colors[Math.floor(Math.random() * colors.length)];
      const geo = new THREE.PlaneGeometry(0.12, 0.3);
      const mat = new THREE.MeshBasicMaterial({ color, side: THREE.DoubleSide });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(x + (Math.random() - 0.5) * 0.5, y + (Math.random() - 0.5) * 0.5, (Math.random() - 0.5) * 0.3);
      mesh.rotation.z = Math.random() * Math.PI;
      this.scene.add(mesh);

      this.particles.push({
        mesh,
        velocity: new THREE.Vector3(
          (Math.random() - 0.5) * 5,
          2 + Math.random() * 3,
          (Math.random() - 0.5) * 1.5
        ),
        life: 0,
        maxLife: 0.8 + Math.random() * 0.6,
      });
    }
  }

  spawnScorePopup(x: number, y: number) {
    // Gold ring burst
    this.spawnExplosion(x, y, 0xffd700, 12);
    // White sparkle
    this.spawnExplosion(x, y, 0xffffff, 6);
  }

  update(dt: number) {
    const gravity = -9;
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life += dt;

      if (p.life >= p.maxLife) {
        this.scene.remove(p.mesh);
        p.mesh.geometry.dispose();
        (p.mesh.material as THREE.Material).dispose();
        this.particles.splice(i, 1);
        continue;
      }

      const t = p.life / p.maxLife;
      p.velocity.y += gravity * dt;
      p.mesh.position.addScaledVector(p.velocity, dt);
      p.mesh.rotation.z += dt * 5;

      // Fade out
      const mat = p.mesh.material as THREE.MeshBasicMaterial;
      mat.opacity = 1 - t;
      mat.transparent = true;

      // Scale down
      const scale = 1 - t * 0.5;
      p.mesh.scale.setScalar(scale);
    }
  }

  clear() {
    this.particles.forEach(p => {
      this.scene.remove(p.mesh);
      p.mesh.geometry.dispose();
      (p.mesh.material as THREE.Material).dispose();
    });
    this.particles = [];
  }
}
