// HUD rendered as HTML overlay on top of the Three.js canvas
// Manages score display, game over screen, and start screen

export type GameState = 'start' | 'playing' | 'dead' | 'countdown';

export class HUD {
  private container: HTMLElement;
  private scoreEl: HTMLElement;
  private overlayEl: HTMLElement;
  private titleEl: HTMLElement;
  private subtitleEl: HTMLElement;
  private bestEl: HTMLElement;
  private currentScoreEl: HTMLElement;
  private medalEl: HTMLElement;
  private countdownEl: HTMLElement;

  constructor(parent: HTMLElement) {
    this.container = document.createElement('div');
    this.container.style.cssText = `
      position: absolute; top: 0; left: 0; width: 100%; height: 100%;
      pointer-events: none; user-select: none; font-family: 'Arial Black', 'Arial', sans-serif;
      overflow: hidden;
    `;
    parent.appendChild(this.container);

    // Score display (top center)
    this.scoreEl = document.createElement('div');
    this.scoreEl.style.cssText = `
      position: absolute; top: 24px; left: 50%; transform: translateX(-50%);
      font-size: 52px; font-weight: 900; color: white;
      text-shadow: 3px 3px 0 #c77800, -1px -1px 0 #c77800, 1px -1px 0 #c77800, -1px 1px 0 #c77800;
      letter-spacing: 4px; display: none;
    `;
    this.container.appendChild(this.scoreEl);

    // Countdown
    this.countdownEl = document.createElement('div');
    this.countdownEl.style.cssText = `
      position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
      font-size: 120px; font-weight: 900; color: white;
      text-shadow: 4px 4px 0 #c77800, -2px -2px 0 #c77800;
      display: none; animation: pulse 0.5s ease-out;
    `;
    this.container.appendChild(this.countdownEl);

    // Full-screen overlay for menus
    this.overlayEl = document.createElement('div');
    this.overlayEl.style.cssText = `
      position: absolute; top: 0; left: 0; width: 100%; height: 100%;
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      background: rgba(0,0,0,0.35); backdrop-filter: blur(2px);
      gap: 16px; pointer-events: none;
    `;
    this.container.appendChild(this.overlayEl);

    // Title
    this.titleEl = document.createElement('div');
    this.titleEl.style.cssText = `
      font-size: 68px; font-weight: 900; color: #ffe600;
      text-shadow: 4px 4px 0 #b07000, -2px -2px 0 #b07000, 2px -2px 0 #b07000, -2px 2px 0 #b07000;
      letter-spacing: 4px; text-align: center; line-height: 1.1;
    `;
    this.overlayEl.appendChild(this.titleEl);

    // Best score
    this.bestEl = document.createElement('div');
    this.bestEl.style.cssText = `
      font-size: 22px; font-weight: 700; color: #ffe066;
      text-shadow: 1px 1px 0 #8a5e00; display: none;
    `;
    this.overlayEl.appendChild(this.bestEl);

    // Medal
    this.medalEl = document.createElement('div');
    this.medalEl.style.cssText = `
      font-size: 80px; display: none; animation: drop 0.5s ease-out;
    `;
    this.overlayEl.appendChild(this.medalEl);

    // Current score on death screen
    this.currentScoreEl = document.createElement('div');
    this.currentScoreEl.style.cssText = `
      font-size: 38px; font-weight: 900; color: white;
      text-shadow: 2px 2px 0 #c77800; display: none;
    `;
    this.overlayEl.appendChild(this.currentScoreEl);

    // Subtitle / instruction
    this.subtitleEl = document.createElement('div');
    this.subtitleEl.style.cssText = `
      font-size: 22px; font-weight: 700; color: white;
      text-shadow: 2px 2px 0 #0006;
      background: rgba(0,0,0,0.4); padding: 12px 32px; border-radius: 30px;
      border: 2px solid rgba(255,255,255,0.3);
      animation: float 2s ease-in-out infinite;
    `;
    this.overlayEl.appendChild(this.subtitleEl);

    // CSS Animations
    const style = document.createElement('style');
    style.textContent = `
      @keyframes float {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-8px); }
      }
      @keyframes drop {
        0% { transform: scale(0) rotate(-30deg); opacity: 0; }
        80% { transform: scale(1.2) rotate(5deg); opacity: 1; }
        100% { transform: scale(1) rotate(0); opacity: 1; }
      }
      @keyframes pulse {
        0% { transform: translate(-50%, -50%) scale(1.5); opacity: 0; }
        100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
      }
      @keyframes scorePop {
        0% { transform: translateX(-50%) scale(1.5); }
        100% { transform: translateX(-50%) scale(1); }
      }
    `;
    document.head.appendChild(style);
  }

  showStart() {
    this.overlayEl.style.display = 'flex';
    this.titleEl.innerHTML = '🐦 FLAPPY<br>BIRD 3D';
    this.subtitleEl.textContent = '🖱 Clique ou Espaço para voar!';
    this.bestEl.style.display = 'none';
    this.currentScoreEl.style.display = 'none';
    this.medalEl.style.display = 'none';
    this.scoreEl.style.display = 'none';
    this.countdownEl.style.display = 'none';
  }

  showPlaying(score: number) {
    this.overlayEl.style.display = 'none';
    this.countdownEl.style.display = 'none';
    this.scoreEl.style.display = 'block';
    this.scoreEl.textContent = String(score);
    this.scoreEl.style.animation = 'scorePop 0.15s ease-out';
    setTimeout(() => { this.scoreEl.style.animation = ''; }, 150);
  }

  showDead(score: number, best: number) {
    this.overlayEl.style.display = 'flex';
    this.titleEl.innerHTML = '💀 GAME OVER';
    this.titleEl.style.color = '#ff4444';

    this.currentScoreEl.style.display = 'block';
    this.currentScoreEl.textContent = `Pontuação: ${score}`;

    this.bestEl.style.display = 'block';
    this.bestEl.textContent = `🏆 Melhor: ${best}`;

    this.medalEl.style.display = 'block';
    this.medalEl.style.animation = 'drop 0.6s ease-out';
    if (score >= 30) this.medalEl.textContent = '🥇';
    else if (score >= 20) this.medalEl.textContent = '🥈';
    else if (score >= 10) this.medalEl.textContent = '🥉';
    else if (score >= 5) this.medalEl.textContent = '🌟';
    else this.medalEl.textContent = '💔';

    this.subtitleEl.textContent = '🖱 Clique ou Espaço para tentar novamente';
    this.scoreEl.style.display = 'none';
  }

  showCountdown(num: number) {
    this.overlayEl.style.display = 'none';
    this.scoreEl.style.display = 'none';
    this.countdownEl.style.display = 'block';
    this.countdownEl.textContent = num === 0 ? 'VAI!' : String(num);
    this.countdownEl.style.animation = 'none';
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        this.countdownEl.style.animation = 'pulse 0.5s ease-out';
      });
    });
  }

  updateScore(score: number) {
    this.scoreEl.textContent = String(score);
    this.scoreEl.style.animation = 'none';
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        this.scoreEl.style.animation = 'scorePop 0.15s ease-out';
      });
    });
  }

  hide() {
    this.overlayEl.style.display = 'none';
    this.scoreEl.style.display = 'none';
    this.countdownEl.style.display = 'none';
  }
}
