// Game constants
export const GAME_WIDTH = 800;
export const GAME_HEIGHT = 600;

export const GRAVITY = -18;
export const FLAP_FORCE = 7;
export const PIPE_SPEED = 3.5;
export const PIPE_GAP = 4.2;
export const PIPE_SPAWN_INTERVAL = 2.2; // seconds
export const PIPE_WIDTH = 1.2;
export const PIPE_DEPTH = 1.2;

export const BIRD_START_X = -3;
export const BIRD_START_Y = 0;
export const BIRD_RADIUS = 0.35;

export const GROUND_Y = -5;
export const CEILING_Y = 6;

export const PIPE_MIN_Y = -3;
export const PIPE_MAX_Y = 2;

export const COLORS = {
  SKY_TOP: 0x4ec0f0,
  SKY_BOTTOM: 0x87e8f5,
  BIRD_BODY: 0xffd700,
  BIRD_WING: 0xff8c00,
  BIRD_BEAK: 0xff6600,
  BIRD_EYE: 0xffffff,
  BIRD_PUPIL: 0x111111,
  BIRD_BELLY: 0xffe066,
  PIPE_GREEN: 0x2ecc40,
  PIPE_DARK: 0x1a8a2a,
  PIPE_CAP: 0x27ae60,
  GROUND_TOP: 0xd4a017,
  GROUND_SIDE: 0x8b5e0a,
  CLOUD: 0xffffff,
  SCORE_BG: 0x000000,
  STAR: 0xfffde7,
};
