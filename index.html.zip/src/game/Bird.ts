import * as THREE from 'three';
import { COLORS, BIRD_RADIUS, GRAVITY, FLAP_FORCE, CEILING_Y } from './constants';

export class Bird {
  group: THREE.Group;
  velocity: number = 0;
  alive: boolean = true;
  flapAngle: number = 0;
  wingUp: boolean = false;
  wingTimer: number = 0;
  deathTimer: number = 0;
  deathRotation: number = 0;

  // Wing references for animation
  leftWing!: THREE.Mesh;
  rightWing!: THREE.Mesh;
  body!: THREE.Mesh;
  beak!: THREE.Mesh;
  eyeL!: THREE.Mesh;
  eyeR!: THREE.Mesh;
  pupilL!: THREE.Mesh;
  pupilR!: THREE.Mesh;
  belly!: THREE.Mesh;
  tailFeather!: THREE.Mesh;

  constructor() {
    this.group = new THREE.Group();
    this.buildBird();
  }

  private buildBird() {
    // --- BODY ---
    const bodyGeo = new THREE.SphereGeometry(BIRD_RADIUS, 20, 16);
    const bodyMat = new THREE.MeshPhongMaterial({
      color: COLORS.BIRD_BODY,
      shininess: 80,
    });
    this.body = new THREE.Mesh(bodyGeo, bodyMat);
    this.body.castShadow = true;
    this.group.add(this.body);

    // --- BELLY (lighter patch) ---
    const bellyGeo = new THREE.SphereGeometry(BIRD_RADIUS * 0.62, 16, 12);
    const bellyMat = new THREE.MeshPhongMaterial({ color: COLORS.BIRD_BELLY, shininess: 40 });
    this.belly = new THREE.Mesh(bellyGeo, bellyMat);
    this.belly.position.set(0.08, -0.05, 0.22);
    this.belly.scale.set(1, 0.75, 0.5);
    this.group.add(this.belly);

    // --- LEFT WING ---
    const wingGeo = new THREE.SphereGeometry(BIRD_RADIUS * 0.7, 12, 8);
    const wingMat = new THREE.MeshPhongMaterial({ color: COLORS.BIRD_WING, shininess: 60 });
    this.leftWing = new THREE.Mesh(wingGeo, wingMat);
    this.leftWing.scale.set(0.35, 0.7, 0.9);
    this.leftWing.position.set(-BIRD_RADIUS * 0.75, 0, 0);
    this.leftWing.castShadow = true;
    this.group.add(this.leftWing);

    // --- RIGHT WING ---
    this.rightWing = new THREE.Mesh(wingGeo, wingMat);
    this.rightWing.scale.set(0.35, 0.7, 0.9);
    this.rightWing.position.set(BIRD_RADIUS * 0.75, 0, 0);
    this.rightWing.castShadow = true;
    this.group.add(this.rightWing);

    // --- BEAK ---
    const beakGeo = new THREE.ConeGeometry(0.1, 0.28, 8);
    const beakMat = new THREE.MeshPhongMaterial({ color: COLORS.BIRD_BEAK, shininess: 80 });
    this.beak = new THREE.Mesh(beakGeo, beakMat);
    this.beak.rotation.z = -Math.PI / 2;
    this.beak.position.set(BIRD_RADIUS * 0.9, 0.04, 0.1);
    this.group.add(this.beak);

    // --- EYES ---
    const eyeGeo = new THREE.SphereGeometry(0.1, 10, 10);
    const eyeMat = new THREE.MeshPhongMaterial({ color: COLORS.BIRD_EYE, shininess: 100 });
    this.eyeR = new THREE.Mesh(eyeGeo, eyeMat);
    this.eyeR.position.set(0.22, 0.12, 0.28);
    this.group.add(this.eyeR);

    this.eyeL = new THREE.Mesh(eyeGeo, eyeMat);
    this.eyeL.position.set(0.22, 0.12, -0.28);
    this.group.add(this.eyeL);

    // --- PUPILS ---
    const pupilGeo = new THREE.SphereGeometry(0.055, 8, 8);
    const pupilMat = new THREE.MeshPhongMaterial({ color: COLORS.BIRD_PUPIL, shininess: 200 });
    this.pupilR = new THREE.Mesh(pupilGeo, pupilMat);
    this.pupilR.position.set(0.29, 0.14, 0.3);
    this.group.add(this.pupilR);

    this.pupilL = new THREE.Mesh(pupilGeo, pupilMat);
    this.pupilL.position.set(0.29, 0.14, -0.3);
    this.group.add(this.pupilL);

    // --- TAIL FEATHER ---
    const tailGeo = new THREE.ConeGeometry(0.15, 0.4, 6);
    const tailMat = new THREE.MeshPhongMaterial({ color: COLORS.BIRD_WING, shininess: 60 });
    this.tailFeather = new THREE.Mesh(tailGeo, tailMat);
    this.tailFeather.rotation.z = Math.PI / 2;
    this.tailFeather.position.set(-BIRD_RADIUS * 0.9, -0.05, 0);
    this.group.add(this.tailFeather);

    // Position
    this.group.position.set(-3, 0, 0);
  }

  flap() {
    if (!this.alive) return;
    this.velocity = FLAP_FORCE;
    this.wingTimer = 0;
    this.wingUp = true;
  }

  update(dt: number) {
    if (!this.alive) {
      // Death spin
      this.deathTimer += dt;
      this.velocity += GRAVITY * dt;
      this.group.position.y += this.velocity * dt;
      this.group.rotation.z -= dt * 4;
      return;
    }

    // Physics
    this.velocity += GRAVITY * dt;
    this.group.position.y += this.velocity * dt;

    // Clamp ceiling
    if (this.group.position.y > CEILING_Y - BIRD_RADIUS) {
      this.group.position.y = CEILING_Y - BIRD_RADIUS;
      this.velocity = 0;
    }

    // Rotation based on velocity
    const targetRot = THREE.MathUtils.clamp(this.velocity * 0.08, -Math.PI / 2.2, Math.PI / 5);
    this.group.rotation.z = THREE.MathUtils.lerp(this.group.rotation.z, targetRot, 0.18);

    // Wing animation
    this.wingTimer += dt;
    const wingSpeed = Math.abs(this.velocity) > 2 ? 8 : 4;
    Math.sin(this.wingTimer * wingSpeed) * 0.4; // wingAngle unused but kept for reference
    this.leftWing.position.y = Math.sin(this.wingTimer * wingSpeed) * 0.12;
    this.rightWing.position.y = Math.sin(this.wingTimer * wingSpeed) * 0.12;

    // Subtle body bob
    this.body.position.y = Math.sin(this.wingTimer * 3) * 0.01;
  }

  getY() {
    return this.group.position.y;
  }

  die() {
    this.alive = false;
  }

  reset() {
    this.alive = true;
    this.velocity = 0;
    this.group.position.set(-3, 0, 0);
    this.group.rotation.z = 0;
    this.deathTimer = 0;
  }
}
