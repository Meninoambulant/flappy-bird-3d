import * as THREE from 'three';
import { Bird } from './Bird';
import { Pipe } from './Pipe';
import { Environment } from './Environment';
import { ParticleSystem } from './Particles';
import { HUD } from './HUD';
import {
  BIRD_RADIUS,
  GROUND_Y,
  PIPE_SPAWN_INTERVAL,
  PIPE_MIN_Y,
  PIPE_MAX_Y,
  PIPE_GAP,
} from './constants';

type GameState = 'start' | 'playing' | 'dead' | 'countdown';

export class FlappyGame {
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private bird: Bird;
  private pipes: Pipe[] = [];
  private environment: Environment;
  private particles: ParticleSystem;
  private hud: HUD;

  private state: GameState = 'start';
  private score: number = 0;
  private bestScore: number = 0;
  private pipeTimer: number = 0;
  private animId: number = 0;
  private lastTime: number = 0;
  private countdownValue: number = 3;
  private countdownTimer: number = 0;

  // Screen shake
  private shakeIntensity: number = 0;
  private shakeTimer: number = 0;

  // Flash overlay
  private flashMesh!: THREE.Mesh;
  private flashTimer: number = 0;
  private flashDuration: number = 0;

  // Difficulty
  private difficultyTimer: number = 0;
  private currentSpeed: number = 1.0;

  // Idle bird float
  private idleTimer: number = 0;

  constructor(private container: HTMLElement) {
    // Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    container.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.position = 'absolute';
    this.renderer.domElement.style.top = '0';
    this.renderer.domElement.style.left = '0';

    // Scene
    this.scene = new THREE.Scene();
    this.scene.fog = new THREE.FogExp2(0x87e8f5, 0.018);

    // Camera
    this.camera = new THREE.PerspectiveCamera(
      60,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    this.camera.position.set(0, 0, 13);
    this.camera.lookAt(0, 0, 0);

    // Lighting
    this.setupLighting();

    // Flash mesh (white overlay for death effect)
    this.setupFlash();

    // Environment
    this.environment = new Environment(this.scene);

    // Bird
    this.bird = new Bird();
    this.scene.add(this.bird.group);

    // Particles
    this.particles = new ParticleSystem(this.scene);

    // HUD
    this.hud = new HUD(container);
    this.hud.showStart();

    // Load best score
    const saved = localStorage.getItem('flappy3d_best');
    if (saved) this.bestScore = parseInt(saved);

    // Events
    this.setupEvents();

    // Resize
    window.addEventListener('resize', this.onResize.bind(this));

    // Start loop
    this.loop(0);
  }

  private setupLighting() {
    // Ambient
    const ambient = new THREE.AmbientLight(0xc8e8ff, 0.75);
    this.scene.add(ambient);

    // Sun
    const sun = new THREE.DirectionalLight(0xfff0cc, 1.4);
    sun.position.set(6, 12, 10);
    sun.castShadow = true;
    sun.shadow.mapSize.width = 2048;
    sun.shadow.mapSize.height = 2048;
    sun.shadow.camera.near = 0.5;
    sun.shadow.camera.far = 60;
    sun.shadow.camera.left = -20;
    sun.shadow.camera.right = 20;
    sun.shadow.camera.top = 20;
    sun.shadow.camera.bottom = -20;
    sun.shadow.bias = -0.001;
    this.scene.add(sun);

    // Fill (cool blue from opposite side)
    const fill = new THREE.DirectionalLight(0x7bbfff, 0.45);
    fill.position.set(-8, 5, 6);
    this.scene.add(fill);

    // Rim light (warm orange from behind)
    const rim = new THREE.PointLight(0xff9944, 0.8, 40);
    rim.position.set(-2, 4, -4);
    this.scene.add(rim);

    // Ground bounce
    const bounce = new THREE.HemisphereLight(0x4ec0f0, 0xd4a017, 0.3);
    this.scene.add(bounce);
  }

  private setupFlash() {
    const geo = new THREE.PlaneGeometry(200, 200);
    const mat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0,
      depthTest: false,
      depthWrite: false,
    });
    this.flashMesh = new THREE.Mesh(geo, mat);
    this.flashMesh.position.z = 12.5;
    this.flashMesh.renderOrder = 999;
    this.scene.add(this.flashMesh);
  }

  private triggerFlash(duration: number = 0.3) {
    this.flashTimer = 0;
    this.flashDuration = duration;
  }

  private triggerShake(intensity: number = 0.35, duration: number = 0.5) {
    this.shakeIntensity = intensity;
    this.shakeTimer = duration;
  }

  private setupEvents() {
    const onInput = (e?: Event) => {
      if (e) e.preventDefault();
      this.handleInput();
    };

    window.addEventListener('keydown', (e) => {
      if (e.code === 'Space' || e.key === ' ' || e.key === 'ArrowUp' || e.code === 'ArrowUp') {
        onInput(e);
      }
    });

    this.renderer.domElement.addEventListener('pointerdown', (e) => onInput(e));
    // Prevent touch scroll
    this.container.addEventListener('touchstart', (e) => { e.preventDefault(); onInput(); }, { passive: false });
  }

  private handleInput() {
    if (this.state === 'start') {
      this.startCountdown();
    } else if (this.state === 'playing') {
      this.bird.flap();
      // Tiny wing-flap particle burst
      this.particles.spawnExplosion(
        this.bird.group.position.x - 0.1,
        this.bird.group.position.y - 0.25,
        0xffe580,
        5
      );
    } else if (this.state === 'dead') {
      this.resetGame();
    }
  }

  private startCountdown() {
    this.state = 'countdown';
    this.countdownValue = 3;
    this.countdownTimer = 0;
    this.hud.showCountdown(3);
    // Reset score and difficulty for new game
    this.score = 0;
    this.currentSpeed = 1.0;
    this.difficultyTimer = 0;
    this.pipeTimer = 0;
  }

  private startGame() {
    this.state = 'playing';
    this.hud.showPlaying(0);
    this.bird.flap();
  }

  private resetGame() {
    // Remove all pipes
    this.pipes.forEach(p => p.remove(this.scene));
    this.pipes = [];

    // Reset bird
    this.bird.reset();

    // Reset camera
    this.camera.position.set(0, 0, 13);

    // Clear particles
    this.particles.clear();

    // Start countdown
    this.startCountdown();
  }

  private spawnPipe() {
    // Dynamic gap based on score (gets harder)
    const gap = Math.max(PIPE_GAP - this.score * 0.04, 2.6);
    const gapY = PIPE_MIN_Y + Math.random() * (PIPE_MAX_Y - PIPE_MIN_Y);
    const pipe = new Pipe(this.scene, 16, gapY, gap, this.currentSpeed);
    this.pipes.push(pipe);
  }

  private checkCollisions() {
    const birdX = this.bird.group.position.x;
    const birdY = this.bird.group.position.y;

    // Ground collision
    if (birdY - BIRD_RADIUS <= GROUND_Y + 0.1) {
      this.killBird();
      return;
    }

    // Pipe collisions
    for (const pipe of this.pipes) {
      if (pipe.checkCollision(birdX, birdY, BIRD_RADIUS * 0.82)) {
        this.killBird();
        return;
      }
    }
  }

  private killBird() {
    if (!this.bird.alive) return;
    this.bird.die();
    this.state = 'dead';

    // Visual effects
    this.triggerFlash(0.22);
    this.triggerShake(0.45, 0.55);
    this.particles.spawnExplosion(
      this.bird.group.position.x,
      this.bird.group.position.y,
      0xff3333,
      22
    );
    this.particles.spawnFeathers(this.bird.group.position.x, this.bird.group.position.y);

    // Save best
    if (this.score > this.bestScore) {
      this.bestScore = this.score;
      localStorage.setItem('flappy3d_best', String(this.bestScore));
    }

    setTimeout(() => {
      if (this.state === 'dead') {
        this.hud.showDead(this.score, this.bestScore);
      }
    }, 1000);
  }

  private checkScoring() {
    const birdX = this.bird.group.position.x;
    for (const pipe of this.pipes) {
      if (!pipe.passed && pipe.getX() < birdX - 0.3) {
        pipe.passed = true;
        this.score++;
        this.hud.updateScore(this.score);
        this.particles.spawnScorePopup(this.bird.group.position.x, this.bird.group.position.y + 0.8);

        // Every 5 points: milestone effect
        if (this.score % 5 === 0) {
          this.particles.spawnExplosion(0, 5, 0xffd700, 30);
        }
      }
    }
  }

  private loop(time: number) {
    this.animId = requestAnimationFrame(this.loop.bind(this));
    const dt = Math.min((time - this.lastTime) / 1000, 0.05);
    this.lastTime = time;
    if (dt === 0) return;
    this.update(dt);
    this.render();
  }

  private update(dt: number) {
    // Idle float when on start screen
    if (this.state === 'start') {
      this.idleTimer += dt;
      this.bird.group.position.y = Math.sin(this.idleTimer * 1.5) * 0.5;
      this.bird.update(dt);
      this.environment.update(dt);
      return;
    }

    // Countdown logic
    if (this.state === 'countdown') {
      this.countdownTimer += dt;
      this.bird.group.position.y = Math.sin(Date.now() * 0.002) * 0.3;
      this.bird.update(dt);
      this.environment.update(dt);
      if (this.countdownTimer >= 1) {
        this.countdownTimer = 0;
        this.countdownValue--;
        if (this.countdownValue <= 0) {
          this.hud.showCountdown(0);
          setTimeout(() => this.startGame(), 400);
        } else {
          this.hud.showCountdown(this.countdownValue);
        }
      }
      return;
    }

    this.environment.update(dt);
    this.bird.update(dt);

    if (this.state === 'playing') {
      // Difficulty progression
      this.difficultyTimer += dt;
      this.currentSpeed = 1.0 + Math.min(this.score * 0.025, 0.7); // max 70% faster

      // Dynamic pipe spawn interval (faster = more pipes)
      const spawnInterval = Math.max(PIPE_SPAWN_INTERVAL - this.score * 0.02, 1.4);

      // Pipe spawning
      this.pipeTimer += dt;
      if (this.pipeTimer >= spawnInterval) {
        this.pipeTimer = 0;
        this.spawnPipe();
      }

      // Update pipes
      this.pipes.forEach(p => p.update(dt, this.currentSpeed));

      // Remove off-screen pipes
      this.pipes = this.pipes.filter(p => {
        if (p.getX() < -20) {
          p.remove(this.scene);
          return false;
        }
        return true;
      });

      // Collisions & scoring
      this.checkCollisions();
      if (this.bird.alive) this.checkScoring();
    }

    if (this.state === 'dead') {
      // Slow-motion pipes on death
      this.pipes.forEach(p => p.update(dt * 0.25, 1.0));
    }

    // Particles
    this.particles.update(dt);

    // Screen shake
    if (this.shakeTimer > 0) {
      this.shakeTimer -= dt;
      const s = this.shakeIntensity * Math.max(this.shakeTimer, 0);
      this.camera.position.x = (Math.random() - 0.5) * s * 2;
      this.camera.position.y = (Math.random() - 0.5) * s * 2;
      if (this.shakeTimer <= 0) {
        this.camera.position.x = 0;
        this.camera.position.y = 0;
      }
    }

    // Flash
    if (this.flashDuration > 0) {
      this.flashTimer += dt;
      const t = this.flashTimer / this.flashDuration;
      const mat = this.flashMesh.material as THREE.MeshBasicMaterial;
      if (t <= 0.25) {
        mat.opacity = (t / 0.25) * 0.75;
      } else {
        mat.opacity = (1 - (t - 0.25) / 0.75) * 0.75;
      }
      if (this.flashTimer >= this.flashDuration) {
        mat.opacity = 0;
        this.flashDuration = 0;
        this.flashTimer = 0;
      }
    }

    // Camera follows bird Y subtly
    if (this.state === 'playing' && this.shakeTimer <= 0) {
      const targetY = THREE.MathUtils.clamp(this.bird.group.position.y * 0.06, -1.2, 1.2);
      this.camera.position.y = THREE.MathUtils.lerp(this.camera.position.y, targetY, 0.04);
    }
  }

  private render() {
    this.renderer.render(this.scene, this.camera);
  }

  private onResize() {
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  destroy() {
    cancelAnimationFrame(this.animId);
    window.removeEventListener('resize', this.onResize.bind(this));
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode) {
      this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
    }
  }
}
