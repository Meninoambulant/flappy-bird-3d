import * as THREE from 'three';
import { COLORS, PIPE_WIDTH, PIPE_DEPTH, PIPE_GAP, PIPE_SPEED } from './constants';

const PIPE_LENGTH = 18;

function buildPipeMesh(): THREE.Group {
  const group = new THREE.Group();

  // Main tube
  const tubeGeo = new THREE.BoxGeometry(PIPE_WIDTH, PIPE_LENGTH, PIPE_DEPTH);
  const tubeMat = new THREE.MeshPhongMaterial({
    color: COLORS.PIPE_GREEN,
    shininess: 60,
  });
  const tube = new THREE.Mesh(tubeGeo, tubeMat);
  tube.castShadow = true;
  tube.receiveShadow = true;
  group.add(tube);

  // Cap (wider box at the opening)
  const capGeo = new THREE.BoxGeometry(PIPE_WIDTH + 0.3, 0.55, PIPE_DEPTH + 0.3);
  const capMat = new THREE.MeshPhongMaterial({ color: COLORS.PIPE_CAP, shininess: 90 });
  const cap = new THREE.Mesh(capGeo, capMat);
  cap.castShadow = true;
  group.add(cap);

  // Highlight stripe
  const stripeGeo = new THREE.BoxGeometry(PIPE_WIDTH * 0.18, PIPE_LENGTH, PIPE_DEPTH + 0.02);
  const stripeMat = new THREE.MeshPhongMaterial({
    color: 0x55ee55,
    shininess: 100,
    transparent: true,
    opacity: 0.3,
  });
  const stripe = new THREE.Mesh(stripeGeo, stripeMat);
  stripe.position.x = -PIPE_WIDTH * 0.28;
  group.add(stripe);

  // Inner shadow ring
  const innerGeo = new THREE.BoxGeometry(PIPE_WIDTH - 0.1, 0.22, PIPE_DEPTH - 0.1);
  const innerMat = new THREE.MeshBasicMaterial({ color: 0x1a6020, transparent: true, opacity: 0.5 });
  const inner = new THREE.Mesh(innerGeo, innerMat);
  group.add(inner); // will be repositioned per pipe

  return group;
}

export class Pipe {
  group: THREE.Group;
  topPipe: THREE.Group;
  bottomPipe: THREE.Group;
  gapY: number;
  gap: number;
  passed: boolean = false;
  active: boolean = true;

  constructor(scene: THREE.Scene, x: number, gapY: number, gap: number = PIPE_GAP, _speedMult: number = 1) {
    this.group = new THREE.Group();
    this.gapY = gapY;
    this.gap = gap;

    this.topPipe = buildPipeMesh();
    this.bottomPipe = buildPipeMesh();

    // Top pipe: cap at the bottom (opening faces down)
    const topCap = this.topPipe.children[1] as THREE.Mesh;
    topCap.position.y = -PIPE_LENGTH / 2 + 0.28;

    const topInner = this.topPipe.children[3] as THREE.Mesh;
    topInner.position.y = -PIPE_LENGTH / 2;

    // Bottom pipe: cap at the top (opening faces up)
    const botCap = this.bottomPipe.children[1] as THREE.Mesh;
    botCap.position.y = PIPE_LENGTH / 2 - 0.28;

    const botInner = this.bottomPipe.children[3] as THREE.Mesh;
    botInner.position.y = PIPE_LENGTH / 2;

    // Position pipes around gap
    this.topPipe.position.y = gapY + gap / 2 + PIPE_LENGTH / 2;
    this.bottomPipe.position.y = gapY - gap / 2 - PIPE_LENGTH / 2;

    this.group.add(this.topPipe);
    this.group.add(this.bottomPipe);
    this.group.position.x = x;

    scene.add(this.group);
  }

  update(dt: number, speedMult: number = 1) {
    this.group.position.x -= PIPE_SPEED * speedMult * dt;
  }

  getX() {
    return this.group.position.x;
  }

  remove(scene: THREE.Scene) {
    scene.remove(this.group);
    this.group.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        child.geometry.dispose();
        if (Array.isArray(child.material)) {
          child.material.forEach((m) => m.dispose());
        } else {
          (child.material as THREE.Material).dispose();
        }
      }
    });
  }

  checkCollision(birdX: number, birdY: number, birdRadius: number): boolean {
    const pipeX = this.group.position.x;
    const halfW = PIPE_WIDTH / 2 + 0.12;

    // Check horizontal overlap
    if (Math.abs(birdX - pipeX) > halfW + birdRadius) return false;

    // Check vertical: outside gap
    const gapTop = this.gapY + this.gap / 2;
    const gapBottom = this.gapY - this.gap / 2;

    if (birdY + birdRadius > gapTop || birdY - birdRadius < gapBottom) {
      return true;
    }

    return false;
  }
}
