import * as THREE from 'three';
import { GROUND_Y } from './constants';

interface Cloud {
  group: THREE.Group;
  speed: number;
}

export class Environment {
  private clouds: Cloud[] = [];
  private stars!: THREE.Points;
  private ground!: THREE.Mesh;
  private groundStripes: THREE.Mesh[] = [];
  private groundOffset: number = 0;

  constructor(scene: THREE.Scene) {
    this.buildBackground(scene);
    this.buildGround(scene);
    this.buildClouds(scene);
    this.buildCity(scene);
    this.buildStars(scene);
    this.buildBirdsInSky(scene);
  }

  private buildBackground(scene: THREE.Scene) {
    // Multi-band sky gradient using stacked planes
    const bandColors = [
      0x2a6db5, // top - deep blue
      0x4890cc,
      0x62aadd,
      0x80c4e8,
      0xa8d8f0,
      0xc5ebf8, // bottom - pale cyan
    ];
    bandColors.forEach((color, i) => {
      const geo = new THREE.PlaneGeometry(90, 4.5);
      const mat = new THREE.MeshBasicMaterial({ color });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.z = -8;
      mesh.position.y = 12 - i * 4.5;
      scene.add(mesh);
    });

    // Sun
    const sunGeo = new THREE.CircleGeometry(1.4, 32);
    const sunMat = new THREE.MeshBasicMaterial({ color: 0xfff5a0 });
    const sun = new THREE.Mesh(sunGeo, sunMat);
    sun.position.set(7, 7, -7.5);
    scene.add(sun);

    // Sun glow rings
    [2.0, 2.6, 3.2].forEach((r, i) => {
      const gGeo = new THREE.RingGeometry(r - 0.15, r, 32);
      const gMat = new THREE.MeshBasicMaterial({
        color: 0xffe566,
        transparent: true,
        opacity: 0.18 - i * 0.04,
        side: THREE.DoubleSide,
      });
      const gMesh = new THREE.Mesh(gGeo, gMat);
      gMesh.position.set(7, 7, -7.4);
      scene.add(gMesh);
    });
  }

  private buildGround(scene: THREE.Scene) {
    // Grass top strip
    const grassGeo = new THREE.BoxGeometry(90, 0.6, 2.5);
    const grassMat = new THREE.MeshPhongMaterial({ color: 0x5db346, shininess: 10 });
    this.ground = new THREE.Mesh(grassGeo, grassMat);
    this.ground.position.set(0, GROUND_Y + 0.05, -0.5);
    this.ground.receiveShadow = true;
    scene.add(this.ground);

    // Dirt base
    const dirtGeo = new THREE.BoxGeometry(90, 2.5, 2.5);
    const dirtMat = new THREE.MeshPhongMaterial({ color: 0x8b5e0a, shininess: 5 });
    const dirt = new THREE.Mesh(dirtGeo, dirtMat);
    dirt.position.set(0, GROUND_Y - 1.55, -0.5);
    scene.add(dirt);

    // Yellow grass border line
    const borderGeo = new THREE.BoxGeometry(90, 0.1, 2.5);
    const borderMat = new THREE.MeshBasicMaterial({ color: 0x8fd65a });
    const border = new THREE.Mesh(borderGeo, borderMat);
    border.position.set(0, GROUND_Y + 0.38, -0.5);
    scene.add(border);

    // Animated dashes on ground
    for (let i = 0; i < 28; i++) {
      const dashGeo = new THREE.BoxGeometry(1.4, 0.09, 0.08);
      const dashMat = new THREE.MeshBasicMaterial({ color: 0xb8d44a, transparent: true, opacity: 0.55 });
      const dash = new THREE.Mesh(dashGeo, dashMat);
      dash.position.set(i * 3.2 - 44, GROUND_Y + 0.42, 0.6);
      scene.add(dash);
      this.groundStripes.push(dash);
    }
  }

  private buildClouds(scene: THREE.Scene) {
    const cloudData = [
      { x: -16, y: 4.8, z: -5.5, scale: 1.1, speed: 0.25 },
      { x: 4, y: 5.5, z: -6.5, scale: 0.75, speed: 0.18 },
      { x: 18, y: 4.2, z: -5.8, scale: 1.0, speed: 0.22 },
      { x: -28, y: 5.0, z: -4.5, scale: 0.85, speed: 0.30 },
      { x: 30, y: 5.8, z: -6.8, scale: 1.25, speed: 0.15 },
      { x: -38, y: 3.8, z: -5.0, scale: 0.70, speed: 0.28 },
      { x: 38, y: 4.5, z: -5.5, scale: 1.05, speed: 0.20 },
      { x: -6, y: 6.2, z: -7, scale: 0.6, speed: 0.12 },
    ];

    cloudData.forEach(({ x, y, z, scale, speed }) => {
      const cloud = this.buildSingleCloud(scale);
      cloud.position.set(x, y, z);
      scene.add(cloud);
      this.clouds.push({ group: cloud, speed });
    });
  }

  private buildSingleCloud(scale: number): THREE.Group {
    const group = new THREE.Group();
    const mat = new THREE.MeshPhongMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.88,
      shininess: 5,
    });

    const puffs = [
      { x: 0, y: 0, r: 0.75 },
      { x: 0.85, y: -0.1, r: 0.58 },
      { x: -0.85, y: -0.1, r: 0.52 },
      { x: 0.48, y: 0.35, r: 0.52 },
      { x: -0.48, y: 0.28, r: 0.47 },
      { x: 1.45, y: -0.25, r: 0.38 },
      { x: -1.4, y: -0.25, r: 0.35 },
    ];

    puffs.forEach((p) => {
      const geo = new THREE.SphereGeometry(p.r * scale, 10, 8);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(p.x * scale, p.y * scale, 0);
      group.add(mesh);
    });

    return group;
  }

  private buildCity(scene: THREE.Scene) {
    const buildingData = [
      { x: -25, h: 4.2, w: 2.0, color: 0x5b7a99, windows: true },
      { x: -21.5, h: 6.0, w: 1.5, color: 0x3d5a74, windows: true },
      { x: -18, h: 3.2, w: 2.2, color: 0x6a8aa8, windows: true },
      { x: -14.5, h: 5.0, w: 1.7, color: 0x4a6680, windows: true },
      { x: -11, h: 2.8, w: 1.9, color: 0x7090b0, windows: false },
      { x: 13, h: 3.8, w: 2.0, color: 0x5b7a99, windows: true },
      { x: 16.5, h: 5.8, w: 1.6, color: 0x3d5a74, windows: true },
      { x: 20, h: 3.0, w: 2.3, color: 0x6a8aa8, windows: false },
      { x: 23.5, h: 5.2, w: 1.7, color: 0x4a6680, windows: true },
      { x: -36, h: 3.6, w: 2.0, color: 0x5b7a99, windows: false },
      { x: 34, h: 4.0, w: 2.0, color: 0x4a6680, windows: false },
    ];

    buildingData.forEach((b) => {
      const geo = new THREE.BoxGeometry(b.w, b.h, 1.8);
      const mat = new THREE.MeshPhongMaterial({ color: b.color, shininess: 15 });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(b.x, GROUND_Y + b.h / 2 + 0.38, -3.8);

      if (b.windows) {
        const rows = Math.max(Math.floor(b.h / 1.0), 2);
        const cols = 2;
        for (let row = 0; row < rows; row++) {
          for (let col = 0; col < cols; col++) {
            const wGeo = new THREE.BoxGeometry(0.28, 0.24, 0.12);
            const wMat = new THREE.MeshBasicMaterial({
              color: Math.random() > 0.3 ? 0xfffacd : 0x2a3845,
            });
            const wMesh = new THREE.Mesh(wGeo, wMat);
            wMesh.position.set(
              (col - 0.5) * (b.w * 0.45),
              row * 1.0 - b.h / 2 + 0.7,
              0.95
            );
            mesh.add(wMesh);
          }
        }
      }

      // Rooftop antenna
      if (b.h > 4.5) {
        const antGeo = new THREE.CylinderGeometry(0.04, 0.04, 1.2, 6);
        const antMat = new THREE.MeshBasicMaterial({ color: 0xaaaaaa });
        const ant = new THREE.Mesh(antGeo, antMat);
        ant.position.set(0, b.h / 2 + 0.6, 0);
        mesh.add(ant);
      }

      scene.add(mesh);
    });
  }

  private buildStars(scene: THREE.Scene) {
    const count = 120;
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 80;
      positions[i * 3 + 1] = Math.random() * 10 + 2;
      positions[i * 3 + 2] = -7.5;
      const bright = 0.7 + Math.random() * 0.3;
      colors[i * 3] = bright;
      colors[i * 3 + 1] = bright;
      colors[i * 3 + 2] = bright * 0.85 + 0.15;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    const mat = new THREE.PointsMaterial({
      size: 0.14,
      vertexColors: true,
      transparent: true,
      opacity: 0.7,
    });
    this.stars = new THREE.Points(geo, mat);
    scene.add(this.stars);
  }

  private buildBirdsInSky(scene: THREE.Scene) {
    // Small decorative V-shaped birds in the background
    for (let i = 0; i < 5; i++) {
      const group = new THREE.Group();
      const mat = new THREE.MeshBasicMaterial({ color: 0x1a2a3a });

      // Left wing
      const lwGeo = new THREE.PlaneGeometry(0.3, 0.08);
      const lw = new THREE.Mesh(lwGeo, mat);
      lw.rotation.z = 0.4;
      lw.position.set(-0.18, 0, 0);
      group.add(lw);

      // Right wing
      const rwGeo = new THREE.PlaneGeometry(0.3, 0.08);
      const rw = new THREE.Mesh(rwGeo, mat);
      rw.rotation.z = -0.4;
      rw.position.set(0.18, 0, 0);
      group.add(rw);

      group.position.set(
        (Math.random() - 0.5) * 30,
        4 + Math.random() * 4,
        -6.5 + Math.random() * 1.5
      );
      group.scale.setScalar(0.7 + Math.random() * 0.8);
      scene.add(group);
    }
  }

  update(dt: number) {
    // Move clouds
    this.clouds.forEach((c) => {
      c.group.position.x -= c.speed * dt;
      if (c.group.position.x < -50) {
        c.group.position.x = 50;
      }
    });

    // Animate ground stripes (scroll)
    this.groundOffset -= 3.5 * dt;
    if (this.groundOffset <= -3.2) this.groundOffset += 3.2;
    this.groundStripes.forEach((dash, i) => {
      dash.position.x = i * 3.2 - 44 + this.groundOffset;
      if (dash.position.x < -45) dash.position.x += 90;
    });

    // Twinkle stars
    const mat = this.stars.material as THREE.PointsMaterial;
    mat.opacity = 0.5 + Math.sin(Date.now() * 0.0015) * 0.2;
  }
}
