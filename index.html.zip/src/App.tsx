import { useEffect, useRef } from 'react';
import { FlappyGame } from './game/FlappyGame';

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<FlappyGame | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    if (gameRef.current) return;

    gameRef.current = new FlappyGame(containerRef.current);

    return () => {
      gameRef.current?.destroy();
      gameRef.current = null;
    };
  }, []);

  return (
    <div
      ref={containerRef}
      style={{
        width: '100vw',
        height: '100vh',
        position: 'relative',
        overflow: 'hidden',
        background: '#000',
        cursor: 'pointer',
      }}
    />
  );
}
